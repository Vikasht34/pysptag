from .fast_io import *

__doc__ = fast_io.__doc__
if hasattr(fast_io, "__all__"):
    __all__ = fast_io.__all__